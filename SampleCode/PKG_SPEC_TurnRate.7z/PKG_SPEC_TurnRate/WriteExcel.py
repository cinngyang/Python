
# coding: utf-8

# In[11]:


import pandas as pd
import xlsxwriter 
from xlsxwriter.utility import xl_rowcol_to_cell,xl_cell_to_rowcol
from datetime import datetime


class HtmlPnadas():
    
    Number_format='{:,.0f}'
    Pertange_format='{:.2%}'    
    
    def __init__(self):
        
        self.Number_format='{:,.0f}'
        self.Pertange_format='{:.2%}'     
        
    def magnify(self):
        return [dict(selector="th",props=[("background-color", "red"),("font-family", "Calibri"),('color','white')])]
    
        
    def ModifyFormat(df,cell_chFormat={}):   
        
        df=df.style.hide_index()
        df=df.set_properties(**{'border':'1px solid white','font-family':'Calibri',
                           'text-align': 'right',
                           'background-color': 'rgb(211, 211, 211)'})
        df=df.format(cell_chFormat).set_table_styles(magnify())
        
        return df

        

class WriteExcel():
    
    FileName='LexIT'+datetime.now().strftime('%Y/%m/%d').replace('/','')+'.xlsx'
    cell_Header=xlsxwriter.format
    cell_format_Number=xlsxwriter.format
    cell_fron=xlsxwriter.format
    
    workbook=xlsxwriter.Workbook()
        
    def __init__(self,FileName): 
        self.workbook = xlsxwriter.Workbook(FileName)
        self.FileName=FileName
        
        # Excel Format
        self.cell_Header = self.workbook.add_format({'bold': True,'italic':False,'bg_color':'#C61031',
                                   'font_name':'Calibri','font_color':'#FFFFFF'})
        self.cell_Header.set_align('center')
        self.cell_Header.set_text_wrap()
        self.cell_Header.set_font_family
        self.cell_Header.set_shrink()        
        
        # 
        self.cell_fron=self.workbook.add_format({'font_color':'#000000'})
        self.cell_format_Number = self.workbook.add_format({'num_format':"#,##0;[red](#,##0)"})
        self.cell_format_Pertange = self.workbook.add_format({'num_format':0x0a})        
        self.cell_Date=self.workbook.add_format({'num_format':'mm/dd','bg_color':'#C61031',
                                                 'font_color':'#FFFFFF','bold': True,'italic':False})
    
    # Default Foramt
    def AddSheet(self,df,sheetName='sheet1',cell_chFormat={}):
        
        # Header
        # Columns Mapping Format
        worksheet = self.workbook.add_worksheet(sheetName)       

        #Header
        for col_num, value in enumerate(df.columns.values):
            
            row=0
            cName=xl_rowcol_to_cell(row,col_num+1)
            style=self.cell_Header                
            worksheet.write(cName, value, style)

        #RawData , row=df.shape[0] ,  col=df.shape[1]
        for col in range(0,df.shape[1]):
            
            if (df.columns[col] in cell_chFormat):
                style=cell_chFormat[df.columns[col]]
            else:
                style=self.cell_fron                
            
            for row, value in enumerate(df.iloc[:,col]):
                cName=xl_rowcol_to_cell(col,row+1)
                worksheet.write(row+1,col+1, value,style)
                
    # Change Header Foramt
    def AddSheetChForm(self,df,sheetName='sheet1',Head_chFormat={},Raw_chFormat={}):
        
        # Header
        # Columns Mapping Format
        worksheet = self.workbook.add_worksheet(sheetName)
        cell_chFormat={}

        #Header
        for col_num, value in enumerate(df.columns.values):
            
            row=0
            cName=xl_rowcol_to_cell(row,col_num+1)
            
            if (value in Head_chFormat):
                style=Head_chFormat[value]
            else :
                style=self.cell_Header
                
            worksheet.write(cName, value, style)

        #RawData , row=df.shape[0] ,  col=df.shape[1]
        for col in range(0,df.shape[1]):
            
            if (df.columns[col] in Raw_chFormat):
                style=Raw_chFormat[df.columns[col]]
            else:
                style=self.cell_fron                
            
            for row, value in enumerate(df.iloc[:,col]):
                cName=xl_rowcol_to_cell(col,row+1)
                worksheet.write(row+1,col+1, value,style)     
                
        
    def Close(self):
        self.workbook.close()
        
        
    

