
# coding: utf-8

# + PKG 規格自動關閉
# + 目前庫存出貨比率 出貨/[目前庫存]
# + 入庫 / [出貨+入庫]
# + 3 個月內出貨 bin格數量 , 1 個月內入庫 bin 格
# + bin 格數量比對 , 出貨與入庫數量百分比
# + 2019/02/26 新增 bincode 清單
# + 拆分 Bincode 
# + 合併 N/Z 料號
# + 特殊料號處理
# + Insert Planing
# + 庫齡 < 14天不列入review, & 90 未入庫 

# In[1]:


#Load DB 元件
FilePath="D://AP//PythonLen//PKG_SPEC_TurnRate//"
import os
import pandas as pd
import numpy as np 
from dateutil.relativedelta import relativedelta
from datetime import datetime
os.chdir(FilePath)


# In[2]:


# Lxtar component
import ConnectDB as cn
import SqlPkgBinQty as sqlstr
import MailTool as MyMail


# In[3]:


# 取得 SQL 
sSql=sqlstr.SqlStr()
#取得區間 
EndDate=datetime.now()
#下線 90D , 
StarDate=EndDate+relativedelta(months=-3)
#入庫 30D
StarDateM=EndDate+relativedelta(months=-1)
EndDate=EndDate.strftime('%Y/%m/%d')
StarDate=StarDate.strftime('%Y/%m/%d')
StarDateM=StarDateM.strftime('%Y/%m/%d')


# In[4]:


print('StarDate',StarDate)
print('StarDateM',StarDateM)
print('EndDate',EndDate)


# ItemCost 取消
# strSql=sSql.ItemCost(EndDate)
# dbCon=cn.OracCn()
# dfItemCost=dbCon.ExecMSSql_Commend(dbCon.lexmsdb6,'RPT',strSql)

# In[5]:


#產品資訊
strSql=sSql.ModelProp()
dbCon=cn.OracCn()
dtModelPro=dbCon.Exec_OracleCommend(dbCon.T01HIS1,strSql)


# In[6]:


# 入庫資料 now-30D
#strSql=sSql.GepInVInput(StarDate,EndDate)
strSql=sSql.GepInVInput(StarDateM,EndDate)
dbCon=cn.OracCn()
dtInvin=dbCon.Exec_OracleCommend(dbCon.T05HIS01,strSql)


# In[7]:


# 下線資料 , 出貨 5 碼 bin 是否過濾 , now-90D
strSql=sSql.GetShip(StarDate,EndDate)
dtShip=dbCon.Exec_OracleCommend(dbCon.T05HIS01,strSql)


# In[8]:


#工單領用 cz now-90D
strSql=sSql.GetIssueWO(StarDate,EndDate)
dtISWo=dbCon.Exec_OracleCommend(dbCon.C01HIS01,strSql)


# In[9]:


#目前 WHMS 庫存 -now-90D
strSql=sSql.GetNOH()
dbCon=cn.OracCn()
dtNOH_T05=dbCon.Exec_OracleCommend(dbCon.T05HIS01,strSql)
dtNOH_C01=dbCon.Exec_OracleCommend(dbCon.C01HIS01,strSql)
dtNOH_S01=dbCon.Exec_OracleCommend(dbCon.S01HIS01,strSql)


# In[10]:


#Merage C01 & TW INV
dtNOH_C01=pd.merge(dtNOH_C01,dtNOH_S01,how='outer')
dtNOH=pd.merge(dtNOH_C01,dtNOH_T05,how='outer')
del dtNOH_T05,dtNOH_C01,dtNOH_S01


# In[11]:


# bincode 庫齡
strSql=sSql.GetNOHAGE()
dbCon=cn.OracCn()
dtNOHAGE_T05=dbCon.Exec_OracleCommend(dbCon.T05HIS01,strSql)
dtNOHAGE_C01=dbCon.Exec_OracleCommend(dbCon.C01HIS01,strSql)
dtNOHAGE_S01=dbCon.Exec_OracleCommend(dbCon.S01HIS01,strSql)
dtNOHAGE_C01=pd.merge(dtNOHAGE_C01,dtNOHAGE_S01,how='outer')
dtNOHAGE=pd.merge(dtNOHAGE_C01,dtNOHAGE_T05,how='outer')
del dtNOHAGE_T05,dtNOHAGE_C01,dtNOHAGE_S01


# In[12]:


dtNOHAGE.head(2)


# In[13]:


# 分組
maxAge=max(dtNOHAGE['INV_AGE'])
bins=[-1,15,30,61,91,180,360,maxAge]
#lab=["0-15","16-30",'31-60','61-90','91-180','181-360','>360']
lab=[15,30,60,90,180,360,390]
dtNOHAGE['AGE']=pd.cut(dtNOHAGE['INV_AGE'],bins,labels=lab)
#暫時取 MIN Mapping 計算
dtNOHAGE=dtNOHAGE.groupby(['PRODUCTNO','BINCODE'])['AGE'].min()
dtNOHAGE=dtNOHAGE.reset_index()


# In[14]:


dtNOHAGE=dtNOHAGE.rename(columns={'AGE':'MIN_AGE'})


# In[15]:


# Bincode 編碼方式
strSql=sSql.GetSPEC_NamingRule('95%')
dbCon=cn.OracCn()
dfNaming=dbCon.ExecMSSql_Commend(dbCon.lexmsdb2,'Planning',strSql)


# In[16]:


# 工單領用
dfISSWO=dtISWo['WO_QTY'].groupby([dtISWo['PRODUCTNO'],dtISWo['BINCODE']]).sum().to_frame()


# In[17]:


# 主要資料 RawData
dtBin=pd.merge(dtShip,dtInvin,how='outer', left_on=['PRODUCTNO','BINCODE'] , right_on=['PRODUCTNO','BINCODE']).fillna(0)
dtBin=pd.merge(dtBin,dfISSWO,how='outer', left_on=['PRODUCTNO','BINCODE'] , right_on=['PRODUCTNO','BINCODE']).fillna(0)
dtBin=pd.merge(dtBin,dtNOH,how='outer', left_on=['PRODUCTNO','BINCODE'] , right_on=['PRODUCTNO','BINCODE']).fillna(0)


# In[18]:


# Merge Product 
dtBin=pd.merge(dtBin,dtModelPro,how='left', left_on=['PRODUCTNO'] , right_on=['PART_NO'])
dtBin=dtBin.drop(['PART_NO'],axis=1)


# In[19]:


#主資料 Summary , by part_no
# Group by 
dtMain=dtBin.groupby(['PRODUCTNO'],axis=0).agg('sum')
dtMain=dtMain.fillna(0)
dtMain=dtMain.reset_index()


# In[20]:


# 新增 Result Columns
addCols=['INPUT_BIN','SHIP_BIN','NOH_BIN','RISK_BIN',
         'RISK1_BIN','RISK_QTY','RISK1_QTY','UNShip_Ratio','InvFree_Ratio']
for col in addCols:
    dtMain[col]=np.zeros(dtMain.shape[0])


# In[21]:


#取得 BU 分類
strSql=sSql.GetBU()
dbCon=cn.OracCn()
dtBU=dbCon.Exec_OracleCommend(dbCon.T05HIS01,strSql)


# In[22]:


# 增加庫齡資訊
dtBin=pd.merge(dtBin,dtNOHAGE,how='left',left_on=['PRODUCTNO','BINCODE'],
               right_on=['PRODUCTNO','BINCODE'])
dtBin=dtBin.fillna(0)


# In[23]:


# 增加 Model Name Group
dtMain=pd.merge(dtMain,dtModelPro,how='left', left_on=['PRODUCTNO'] , right_on=['PART_NO'])
dtMain=dtMain.drop(['PART_NO'],axis=1)


# 規格處理

# In[24]:


#傳入一個料號 回傳位置 
def GetLenth(dfNaming,sType):
    Pos=dfNaming[dfNaming['SPEC_TYPE']==sType]
    sPos=0
    ePos=0
    if Pos.shape[0] > 0 :
        Pos=Pos.iloc[0,:]
        sPos=int(Pos['CODE_INDEX'])
        ePos=int(Pos['CODE_LENGTH'])
    else :
        sPos=1
        ePos=0
    return {'sPos':sPos-1,'ePos':ePos}     


# In[25]:


#定義要取得的屬性與編碼長度
sTypes=['WL','CIE','IV','VF']
#建立回傳Table
cols=['PRODUCTNO','WL_S','WL_E','CIE_S','CIE_E','IV_S','IV_E','VF_S','VF_E']
ParNameRule=pd.DataFrame()
#ParNameRule=pd.DataFrame(columns=cols)
sValue2={} 

pl=dfNaming.PART_NO.unique()
for p in pl:
    for t in sTypes:
        En=GetLenth(dfNaming[dfNaming['PART_NO']==p],t)
        #print(p)
    #每個料號位置
        sValue2[t]=En
    vals=[p,sValue2['WL']['sPos'],sValue2['WL']['ePos'],sValue2['CIE']['sPos'],sValue2['CIE']['ePos'],
    sValue2['IV']['sPos'],sValue2['IV']['ePos'],sValue2['VF']['sPos'],sValue2['VF']['ePos']]
    ParNameRule=ParNameRule.append(pd.DataFrame([vals]))
ParNameRule.columns=cols


# 合併TW & CZ 料號
# 95.S3806.W0A0AZN / 95.S3806.W0A0AZZ
# PM 規格是否關閉
# W12.3  C8N = C8Z => C8N+EHN = C8Z+EHZ

# In[26]:


#合併TW & CZ 料號 , 建立 PartGroup
#95.S3806.W0A0AZN / 95.S3806.W0A0AZZ
ParGroup=dtBin['PRODUCTNO'].unique().tolist()
ParGroup=sorted(ParGroup)
dtBin['Part_Group']=dtBin['PRODUCTNO'].copy()
dtMain['Part_Group']=dtMain['PRODUCTNO'].copy()
for p in ParGroup:    
#p='95.S3806.W0A0AZN'
    if (p[len(p)-1])=='N':  
        bp=p[0:(len(p)-1)]+'Z'
        dtBin.loc[(dtBin['PRODUCTNO']==p)|(dtBin['PRODUCTNO']==bp),'Part_Group']=p
        dtMain.loc[(dtMain['PRODUCTNO']==p)|(dtMain['PRODUCTNO']==bp),'Part_Group']=p        
    #print(bp)
#dtBin.loc[dtBin['PRODUCTNO']==p]


# In[27]:


# W12.3 C8N = C8Z => C8N+EHN = C8Z+EHZ 20190406
dtMain.loc[dtMain['Part_Group']=='95.S3806.W0A0EHN','Part_Group']='95.S3806.W0A0C8N'
dtBin.loc[dtBin['Part_Group']=='95.S3806.W0A0EHN','Part_Group']='95.S3806.W0A0C8N'


# In[28]:


#主程式  計算BIN 數與取得 BIN CODE , 以 Part Group 計算
def GetRawCount(dtParts,partNo='95.T4014.W0B1B2Z'):   
    
    #以Part Group 處理
    # 出貨 BIN 數 
    rowShip=dtParts.loc[(dtParts['Part_Group']==partNo) & ((dtParts['SHIP'] > 0) | (dtParts['WO_QTY'] > 0)) ].shape
    # 入庫 BIN 數
    rowInput=dtParts.loc[(dtParts['Part_Group']==partNo) & (dtParts['INPUT'] > 0)].shape     
    # 區間內 BIN 數
    rowCount=dtParts.loc[(dtParts['Part_Group']==partNo)].shape
    # 目前庫存 BIN 數
    rowNOH=dtParts.loc[(dtParts['Part_Group']==partNo) & (dtParts['OH_QTY'] > 0)].shape    
    
    # 目前庫存未出貨 BIN 數
    rowRisk=dtParts.loc[(dtParts['Part_Group']==partNo) &
                        (dtParts['OH_QTY'] > 0) & (dtParts['SHIP'] == 0)] 
    # 目前庫存未出貨數量
    riskQty=rowRisk['OH_QTY'].sum()
    
    # 持續入庫 未出貨數量
    rowRisk1=dtParts.loc[(dtParts['Part_Group']==partNo) &
                         (dtParts['INPUT'] > 0) & ((dtParts['SHIP'] == 0) &
                         (dtParts['WO_QTY'] == 0) & (dtParts['MIN_AGE'] > 15) ) ]    
    # 有入庫未出貨數量
    risk1Qty=rowRisk1['OH_QTY'].sum()
    
    #Return
    dic={'INPUT_BIN':rowInput[0],'OutPut_BIN':rowShip[0],'BIN_COUNT':rowCount[0],'NOH_BIN':rowNOH[0],
         'RISK_BIN':rowRisk.shape[0],'RISK1_BIN':rowRisk1.shape[0],'riskQty':riskQty,'risk1Qty':risk1Qty}  
    return dic, rowRisk1[['Part_Group','PRODUCTNO','BINCODE','OH_QTY']],rowRisk


# In[29]:


import time
tStart = time.time()
dfRiskBinS=pd.DataFrame(columns=['PRODUCTNO','BINCODE'])

GroupParts=dtMain['Part_Group'].unique().tolist()



for PART_NO in GroupParts:
    binc,binList,rowRisk=GetRawCount(dtBin,PART_NO)    
    
    #Risk Bin 
    dfRiskBinS=dfRiskBinS.append(binList,sort=False)        
    dtMain.loc[dtMain['Part_Group']==PART_NO,'INPUT_BIN']=binc['INPUT_BIN']
    dtMain.loc[dtMain['Part_Group']==PART_NO,'SHIP_BIN']=binc['OutPut_BIN']
    dtMain.loc[dtMain['Part_Group']==PART_NO,'NOH_BIN']=binc['NOH_BIN']
    dtMain.loc[dtMain['Part_Group']==PART_NO,'RISK_BIN']=binc['RISK_BIN']
    dtMain.loc[dtMain['Part_Group']==PART_NO,'RISK1_BIN']=binc['RISK1_BIN']   
    
    #by 料號計算 Summary
    subParts=dtMain.loc[dtMain['Part_Group']==PART_NO,'PRODUCTNO'].unique().tolist()
    
    for p in subParts:
        riskH=0
        riskSlow=0
        
        riskH=dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'OH_QTY'].sum()       
        riskSlow=rowRisk.loc[rowRisk['PRODUCTNO']==p,'OH_QTY'].sum()
        
        dtMain.loc[dtMain['PRODUCTNO']==p,'RISK1_QTY']=riskH
        dtMain.loc[dtMain['PRODUCTNO']==p,'RISK_QTY']=riskSlow  
        
        if (riskH > riskSlow): print(p)
    
tEnd = time.time()


dtMain['UNShip_Ratio']=dtMain['RISK1_QTY']/dtMain['OH_QTY']
dtMain['InvFree_Ratio']=dtMain['RISK_QTY']/dtMain['OH_QTY']
dtMain['Total']=dtMain['SHIP']+dtMain['WO_QTY']
print("It cost {:.2} sec".format(tEnd - tStart))            


# In[30]:


# 增加拆分 CIE / IV /VF , 新增欄位
dfRiskBinS['PRODUCTNO'].unique()
sTypes=['WL','CIE','IV','VF']
for s in sTypes:
    dfRiskBinS[s]='0'


# In[31]:


# 拆碼
pl=ParNameRule['PRODUCTNO'].unique()

for p in pl:
    WLS=int(ParNameRule.loc[ParNameRule['PRODUCTNO']==p,'WL_S'][0])
    WL_E=int(ParNameRule.loc[ParNameRule['PRODUCTNO']==p,'WL_E'][0])

    CIE_S=int(ParNameRule.loc[ParNameRule['PRODUCTNO']==p,'CIE_S'][0])
    CIE_E=int(ParNameRule.loc[ParNameRule['PRODUCTNO']==p,'CIE_E'][0])

    IV_S=int(ParNameRule.loc[ParNameRule['PRODUCTNO']==p,'IV_S'][0])
    IV_E=int(ParNameRule.loc[ParNameRule['PRODUCTNO']==p,'IV_E'][0])

    VF_S=int(ParNameRule.loc[ParNameRule['PRODUCTNO']==p,'VF_S'][0])
    VF_E=int(ParNameRule.loc[ParNameRule['PRODUCTNO']==p,'VF_E'][0])

#print('WL',WLS,WL_E,'CIE',CIE_S,CIE_E,'IV',IV_S,IV_E,'VF',VF_S,VF_E)
    dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'CIE']    =dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'BINCODE'].str[CIE_S:CIE_E+CIE_S]

    dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'WL']=    dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'BINCODE'].str[WLS:WLS+WL_E]

    dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'IV']=    dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'BINCODE'].str[IV_S:IV_S+IV_E]

    dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'VF']=    dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==p,'BINCODE'].str[VF_S:VF_S+VF_E]


# In[32]:


#串 BU Team

dtBU=(dtBU.assign(rn=dtBU.sort_values(['PRODUCTNO'], ascending=False)
                  .groupby(['PRODUCTNO']).cumcount() + 1).query('rn <= 1')
      .sort_values(['BG', 'rn']))

dtMain=pd.merge(dtMain,dtBU,how='left', left_on=['PRODUCTNO'] , right_on=['PRODUCTNO'])
dtMain=dtMain.drop(['rn'],axis=1)
dtMain.BG=dtMain.BG.fillna('OTHERS')


# In[33]:


# Risk bin merge Model
dfRiskBinS=pd.merge(dfRiskBinS,dtModelPro,how='left', left_on=['PRODUCTNO'] , right_on=['PART_NO'])
dfRiskBinS=dfRiskBinS.drop(['PART_NO'],axis=1)

# dfRiskBinS 增加入庫數量
dfRiskBinS=pd.merge(dfRiskBinS,dtBin[['PRODUCTNO','BINCODE','INPUT']],how='left',
         left_on=['PRODUCTNO','BINCODE'],right_on=['PRODUCTNO','BINCODE'])

dfRiskBinS=pd.merge(dfRiskBinS,dtBU,how='left', left_on=['PRODUCTNO'] , right_on=['PRODUCTNO'])

cols=['BG','MODEL_GROUP','MODEL_NAME','Part_Group','PRODUCTNO','BINCODE','INPUT','OH_QTY','WL', 'CIE', 'IV', 'VF']
dfRiskBinS=dfRiskBinS.reindex(columns=cols)


# In[35]:


#part=dfRiskPart.loc[1,'PRODUCTNO']
#model=dfRiskPart.loc[1,'MODEL_NAME']
#subRisk=dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==part]
#rbin=subRisk.loc[2,'BINCODE']
#MinSub=dfPMSPEC.loc[dfPMSPEC['eng_spec']==rbin,'bin_grade'].tolist()
#if len(MinSub) > 0:
    


# In[36]:


# Risk Bin 判斷規格是否關閉
dfRiskPart=dfRiskBinS.groupby(['MODEL_NAME','PRODUCTNO'])['INPUT'].min()
# dfRiskPart 料號清單
dfRiskPart=dfRiskPart.reset_index()


# In[37]:


# MAIN_BIN 先預設 subMain Bin
dfRiskBinS['MAIN_BIN']='S'
for i in range(0,dfRiskPart.shape[0]):
    # 取得料號 MainBin subMain Bin
    part=dfRiskPart.loc[i,'PRODUCTNO']
    model=dfRiskPart.loc[i,'MODEL_NAME']
    strsql="exec dbo.sp_Get_PM_SPEC_ALL '{0}','{1}'".format(model,part)    
    dfPMSPEC=dbCon.ExecMSSql_Commend(dbCon.lexmsdb2,'Planning',strsql)
    #取 Risk Bin 每個 Bin 逐一檢查
    subRisk=dfRiskBinS.loc[dfRiskBinS['PRODUCTNO']==part]
    for ix in subRisk.index:
        rbin=subRisk.loc[ix,'BINCODE']  
        #print(part,rbin,MinSub)
        MinSub=dfPMSPEC.loc[dfPMSPEC['eng_spec']==rbin,'bin_grade'].tolist()
        if len(MinSub) > 0:
            dfRiskBinS.loc[ix,'MAIN_BIN']=MinSub[0]
        else :
            dfRiskBinS.loc[ix,'MAIN_BIN']='NA'


# # ACTIVE 版次
# # Status defaul turn on for PM review
# dfIns=dfRiskBinS.loc[:,['MODEL_NAME','PRODUCTNO','BINCODE']]
# dfIns['ACTIVE']='N'
# dfIns['Version']=EndDate.replace('/','')
# dfIns['Status']='N'
# dfIns['Owner']='SYS'
# dfIns['Creation_date']=EndDate
# dfIns['Update_date']=EndDate
# 
# dfIns=dfIns.rename(columns={'PRODUCTNO':'PartNo','MODEL_NAME':'ModelName'})
# cols=['ACTIVE','Version','ModelName','PartNo','BINCODE','Status','Owner','Creation_date','Update_date']
# dfIns=dfIns.reindex(columns=cols)

# # Insert DB
# dbCon.InsertMSSQL(dfIns,severName='Lexmsdb2',usr='BinCntrlAP',pwd='BinCntrlAP@admin',dbName='Planning',
#                 tableNmae='[Planning].[dbo].[STOCK_BINCODE_RECORD]')

# 整理 RPT<BR>
# Rename & sorting Columns<BR>
# dtMain<BR>
# dtBin<BR>
# dfRiskBinS<BR>

# In[38]:


# dtMain Columns ReName & Sorting
cols={"SHIP":'出貨','WO_QTY':'工單領用','Total':'出貨總量','SHIP_BIN':'下線BIN數','OH_QTY':'FG_庫存','NOH_BIN':'庫存BIN數',
      'INPUT':'FG入庫','INPUT_BIN':'入庫BIN數',
      'RISK1_BIN':'持續入庫\n 未出貨BIN數','RISK1_QTY':'持續入庫\n 未出貨數量','UNShip_Ratio':'未出貨\n 庫存比例',
      'RISK_QTY':'有庫存\n 不合規數量','RISK_BIN':'有庫存\n 不合規BIN數','InvFree_Ratio':'庫存\n 呆滯比例'}

dtMain=dtMain.rename(columns=cols)

# Columns Sorting
cols=['BG','MODEL_GROUP','MODEL_NAME','Part_Group','PRODUCTNO','出貨','工單領用','出貨總量','下線BIN數','FG_庫存','庫存BIN數',
      'FG入庫','入庫BIN數','持續入庫\n 未出貨BIN數','持續入庫\n 未出貨數量','未出貨\n 庫存比例',
      '有庫存\n 不合規數量','有庫存\n 不合規BIN數','庫存\n 呆滯比例']
dtMain=dtMain.reindex(columns=cols)
dtMain=dtMain.fillna(0)


# In[39]:


dtBin.head(2)


# In[40]:


# dtBin Columns ReName & Sortint 
cols=['MODEL_GROUP', 'MODEL_NAME','PRODUCTNO','Part_Group','BINCODE','MIN_AGE'
      ,'SHIP', 'INPUT', 'WO_QTY', 'OH_QTY']
dtBin=dtBin.reindex(columns=cols)

cols={"SHIP":'出貨','WO_QTY':'工單領用','INPUT':'FG入庫','OH_QTY':'FG_庫存'}
dtBin=dtBin.rename(columns=cols)
dtBin=dtBin.fillna(0)


# In[41]:


dtBin.head(2)


# In[42]:


dfRiskBinS.head(2)


# In[61]:


# dtBin Columns ReName & Sortint 
dfRiskBinS=dfRiskBinS.rename(columns={'BINCODE':'持續入庫\n 未出貨BIN',
                                      'OH_QTY':'FG_庫存','INPUT':'FG入庫'})
dfRiskBinS=dfRiskBinS.fillna('Others')


# In[44]:


# 排序
dtMain=dtMain.sort_values(by=['持續入庫\n 未出貨數量','FG_庫存'],ascending=False)


# In[45]:


# Modle Group Summary
dtMGSum=dtMain.groupby(['BG','MODEL_GROUP'],axis=0).agg('sum')
dtMGSum=dtMGSum.sort_values(by=['持續入庫\n 未出貨數量'],ascending=False)
dtMGSum=dtMGSum.reset_index()
cols=['BG','MODEL_GROUP','FG_庫存','有庫存\n 不合規BIN數','有庫存\n 不合規數量','入庫BIN數','持續入庫\n 未出貨BIN數','持續入庫\n 未出貨數量']
dtMGSum=dtMGSum.reindex(columns=cols) 


# In[63]:


dtMGSum.head(2)


# Excel 處理

# In[64]:


# 土法煉鋼 By Columns寫
import xlsxwriter 
FileName='BinCode下線率_Summary'+EndDate.replace('/','')+'.xlsx'
workbook = xlsxwriter.Workbook(FileName)


# In[65]:


# 0x03:#,##0 , 0x0a: %.##
cell_Header = workbook.add_format({'bold': True,'italic':False,'bg_color':'#C61031',
                                   'font_name':'Calibri','font_color':'#FFFFFF'})
cell_Header.set_align('center')
cell_Header.set_text_wrap()
cell_Header.set_font_family
cell_Header.set_shrink()
# Excel Format
cell_format_Number = workbook.add_format({'num_format':0x25})
cell_format_Pertange = workbook.add_format({'num_format':0x0a})
cell_fron=workbook.add_format({'font_color':'#000000'})


# In[66]:


# Sheet1
# Header
# Columns Mapping Format
worksheetMG = workbook.add_worksheet('ModelGroupSummary')
cell_chFormat={'MODEL_GROUP':cell_fron,'FG_庫存':cell_format_Number,'有庫存\n 不合規BIN數':cell_format_Number,
               '有庫存\n 不合規數量':cell_format_Number,'入庫BIN數':cell_format_Number,
               '持續入庫\n 未出貨BIN數':cell_format_Number,'BG':cell_fron,
               '持續入庫\n 未出貨數量':cell_format_Number}

for col_num, value in enumerate(dtMGSum.columns.values):
    worksheetMG.write(0, col_num + 1, value, cell_Header)

#RawData , row=df.shape[0]
for i in range(0,dtMGSum.shape[1]):
    for row, value in enumerate(dtMGSum.iloc[:,i]):
        style=cell_chFormat[dtMGSum.columns[i]]
        worksheetMG.write(row+1,i+1, value,style)


# In[67]:


#df.replace([np.inf, -np.inf], np.nan)
print(dtMain.loc[dtMain['庫存\n 呆滯比例']==np.inf,'PRODUCTNO'])
dtMain=dtMain.replace([np.inf, -np.inf], 0)


# In[68]:


# Sheet1
# Header
# Columns Mapping Format
worksheet = workbook.add_worksheet('Part Summary')
cell_chFormat={'MODEL_GROUP':cell_fron,'MODEL_NAME':cell_fron,'Part_Group':cell_fron,
               'PRODUCTNO':cell_fron,'出貨':cell_format_Number,
               '工單領用':cell_format_Number,'出貨總量':cell_format_Number,
               '下線BIN數':cell_format_Number,'FG_庫存':cell_format_Number,
               '庫存BIN數':cell_format_Number,
               'FG入庫':cell_format_Number,'入庫BIN數':cell_format_Number,
               '持續入庫\n 未出貨BIN數':cell_format_Number,
               '持續入庫\n 未出貨數量':cell_format_Number,'未出貨\n 庫存比例':cell_format_Pertange,
               '有庫存\n 不合規數量':cell_format_Number,
               '有庫存\n 不合規BIN數':cell_format_Number,'BG':cell_fron,
               '庫存\n 呆滯比例':cell_format_Pertange}

for col_num, value in enumerate(dtMain.columns.values):
    worksheet.write(0, col_num + 1, value, cell_Header)

#RawData , row=df.shape[0]
for i in range(0,dtMain.shape[1]):
    for row, value in enumerate(dtMain.iloc[:,i]):
        style=cell_chFormat[dtMain.columns[i]]
        worksheet.write(row+1,i+1, value,style)


# In[69]:


dfRiskBinS.columns


# In[70]:


# Sheet2 
worksheet2 = workbook.add_worksheet('RiskBin')
cell_chFormat={'BG':cell_fron,'MODEL_GROUP':cell_fron,'MODEL_NAME':cell_fron,'PRODUCTNO':cell_fron,
               '持續入庫\n 未出貨BIN':cell_fron,'FG_庫存':cell_format_Number,'Part_Group':cell_fron,
               'MAIN_BIN':cell_fron,'FG入庫':cell_format_Number, 
               'WL':cell_fron, 'CIE':cell_fron, 'IV':cell_fron, 'VF':cell_fron}

# Header
for col_num, value in enumerate(dfRiskBinS.columns.values):
    worksheet2.write(0, col_num + 1, value, cell_Header)

#RawData , row=df.shape[0]
for i in range(0,dfRiskBinS.shape[1]):
    for row, value in enumerate(dfRiskBinS.iloc[:,i]):
        style=cell_chFormat[dfRiskBinS.columns[i]]
        worksheet2.write(row+1,i+1, value,style)


# In[71]:


# Sheet3 
worksheet3 = workbook.add_worksheet('BinRawData')
cell_chFormat={'MODEL_GROUP':cell_fron,'MODEL_NAME':cell_fron,'PRODUCTNO':cell_fron,
               'BINCODE':cell_fron,'出貨':cell_format_Number,'工單領用':cell_format_Number,
               'FG入庫':cell_format_Number,'FG_庫存':cell_format_Number,
               'Part_Group':cell_fron,'MIN_AGE':cell_format_Number}
# Header
for col_num, value in enumerate(dtBin.columns.values):
    worksheet3.write(0, col_num + 1, value, cell_Header)

#RawData , row=df.shape[0]
for i in range(0,dtBin.shape[1]):
    for row, value in enumerate(dtBin.iloc[:,i]):
        style=cell_chFormat[dtBin.columns[i]]
        worksheet3.write(row+1,i+1, value,style)


# In[72]:


workbook.close()


# Mail

# In[73]:


def magnify():
    return [dict(selector="th",props=[("background-color", "red"),("font-family", "Calibri"),('color','white')])]


# In[74]:


# Mail Header Message BL
HtmlBL_MG=dtMGSum[dtMGSum['BG']=='BL'].sort_values(by=['持續入庫\n 未出貨數量'],ascending=False)
HtmlBL_MG=HtmlBL_MG.iloc[0:10,:]

# Mail Header Message
HtmlBL_Part=dtMain[dtMain['BG']=='BL'].sort_values(by=['持續入庫\n 未出貨數量'],ascending=False)
HtmlBL_Part=HtmlBL_Part.iloc[0:10,:]
HtmlBL_Part=HtmlBL_Part.drop(['出貨','工單領用'],axis=1)


# In[75]:


# Mail Header Message LT
HtmlLT_MG=dtMGSum[dtMGSum['BG']=='LT'].sort_values(by=['持續入庫\n 未出貨數量'],ascending=False)
HtmlLT_MG=HtmlLT_MG.iloc[0:10,:]

# Mail Header Message
HtmlLT_Part=dtMain[dtMain['BG']=='LT'].sort_values(by=['持續入庫\n 未出貨數量'],ascending=False)
HtmlLT_Part=HtmlLT_Part.iloc[0:10,:]
HtmlLT_Part=HtmlLT_Part.drop(['出貨','工單領用'],axis=1)


# In[76]:


HtmlBL_MG=HtmlBL_MG.rename(columns={'MODEL_GROUP':'MODEL<BR>GROUP','FG_庫存':'FG<BR>庫存','有庫存\n 不合規數量':'有庫存<BR>不合規數量',
                              '持續入庫\n 未出貨BIN數':'持續入庫<BR>未出貨BIN數','持續入庫\n 未出貨數量':'持續入庫<BR>未出貨數量',
                              '有庫存\n 不合規BIN數':'有庫存<BR>不合規BIN數'
                             })

HtmlLT_MG=HtmlLT_MG.rename(columns={'MODEL_GROUP':'MODEL<BR>GROUP','FG_庫存':'FG<BR>庫存','有庫存\n 不合規數量':'有庫存<BR>不合規數量',
                              '持續入庫\n 未出貨BIN數':'持續入庫<BR>未出貨BIN數','持續入庫\n 未出貨數量':'持續入庫<BR>未出貨數量',
                              '有庫存\n 不合規BIN數':'有庫存<BR>不合規BIN數'
                             })


# In[77]:


HtmlBL_Part=HtmlBL_Part.rename(columns={'MODEL_GROUP':'MODEL<BR>GROUP','MODEL_NAME':'MODEL<BR>NAME',
                                  'FG_庫存':'FG<BR>庫存','有庫存\n 不合規數量':'有庫存<BR>不合規數量',
                              '持續入庫\n 未出貨BIN數':'持續入庫<BR>未出貨BIN數','持續入庫\n 未出貨數量':'持續入庫<BR>未出貨數量',
                              '有庫存\n 不合規BIN數':'有庫存<BR>不合規BIN數','未出貨\n 庫存比例':'未出貨<BR>庫存比例',
                               '庫存\n 呆滯比例':'庫存<BR>呆滯比例','下線BIN數':'下線<BR>BIN數','入庫BIN數':'入庫<BR>BIN數' 
                             })
HtmlLT_Part=HtmlLT_Part.rename(columns={'MODEL_GROUP':'MODEL<BR>GROUP','MODEL_NAME':'MODEL<BR>NAME',
                                  'FG_庫存':'FG<BR>庫存','有庫存\n 不合規數量':'有庫存<BR>不合規數量',
                              '持續入庫\n 未出貨BIN數':'持續入庫<BR>未出貨BIN數','持續入庫\n 未出貨數量':'持續入庫<BR>未出貨數量',
                              '有庫存\n 不合規BIN數':'有庫存<BR>不合規BIN數','未出貨\n 庫存比例':'未出貨<BR>庫存比例',
                               '庫存\n 呆滯比例':'庫存<BR>呆滯比例','下線BIN數':'下線<BR>BIN數','入庫BIN數':'入庫<BR>BIN數' 
                             })


# In[78]:


# Columns Format Change
cell_chFormat={'FG<BR>庫存':'{:,.0f}','有庫存<BR>不合規BIN數':'{:,.0f}','有庫存<BR>不合規數量':'{:,.0f}','入庫BIN數':'{:,.0f}',
               '持續入庫<BR>未出貨BIN數':'{:,.0f}', '持續入庫<BR>未出貨數量':'{:,.0f}' }
MsgBLMg=HtmlBL_MG.style.format(cell_chFormat).hide_index()
MsgBLMg=MsgBLMg.set_properties(**{'border':'1px solid white','font-family':'Calibri',
                           'text-align': 'right',
                           'background-color': 'rgb(211, 211, 211)'})
MsgBLMg=MsgBLMg.set_table_styles(magnify())

# Columns Format Change
cell_chFormat={'FG<BR>庫存':'{:,.0f}','有庫存<BR>不合規BIN數':'{:,.0f}','有庫存<BR>不合規數量':'{:,.0f}','入庫BIN數':'{:,.0f}',
               '持續入庫<BR>未出貨BIN數':'{:,.0f}', '持續入庫<BR>未出貨數量':'{:,.0f}' }
MsgLTMg=HtmlLT_MG.style.format(cell_chFormat).hide_index()
MsgLTMg=MsgLTMg.set_properties(**{'border':'1px solid white','font-family':'Calibri',
                           'text-align': 'right',
                           'background-color': 'rgb(211, 211, 211)'})
MsgLTMg=MsgLTMg.set_table_styles(magnify())


# In[79]:


# Columns Format Change
cell_chFormat={'出貨總量':'{:,.0f}','下線<BR>BIN數':'{:,.0f}','FG<BR>庫存':'{:,.0f}','庫存<BR>BIN數':'{:,.0f}',
               'FG入庫':'{:,.0f}','入庫<BR>BIN數':'{:,.0f}','持續入庫<BR>未出貨BIN數':'{:,.0f}',
               '持續入庫<BR>未出貨數量':'{:,.0f}','未出貨<BR>庫存比例':'{:.2%}',
               '有庫存<BR>不合規數量':'{:,.0f}','有庫存<BR>不合規BIN數':'{:,.0f}',
               '庫存<BR>呆滯比例':'{:.2%}'}
MsgLTPart=HtmlLT_Part.style.hide_index()
MsgLTPart=MsgLTPart.set_properties(**{'border':'1px solid white','font-family':'Calibri',
                           'text-align': 'right',
                           'background-color': 'rgb(211, 211, 211)'})
MsgLTPart=MsgLTPart.format(cell_chFormat).set_table_styles(magnify())

# Columns Format Change
cell_chFormat={'出貨總量':'{:,.0f}','下線<BR>BIN數':'{:,.0f}','FG<BR>庫存':'{:,.0f}','庫存<BR>BIN數':'{:,.0f}',
               'FG入庫':'{:,.0f}','入庫<BR>BIN數':'{:,.0f}','持續入庫<BR>未出貨BIN數':'{:,.0f}',
               '持續入庫<BR>未出貨數量':'{:,.0f}','未出貨<BR>庫存比例':'{:.2%}',
               '有庫存<BR>不合規數量':'{:,.0f}','有庫存<BR>不合規BIN數':'{:,.0f}',
               '庫存<BR>呆滯比例':'{:.2%}'}
MsgBLPart=HtmlBL_Part.style.hide_index()
MsgBLPart=MsgBLPart.set_properties(**{'border':'1px solid white','font-family':'Calibri',
                           'text-align': 'right',
                           'background-color': 'rgb(211, 211, 211)'})
MsgBLPart=MsgBLPart.format(cell_chFormat).set_table_styles(magnify())


# 調整 HTML

# In[81]:


strDesc='<span style="font-family:Calibri;">'
strDesc+='各料號細項請參閱副件,Risk bincode By CIE/IV/VF/WD <BR>'
strDesc+='出貨:90D,工單領用:90D,FG入庫:30D <BR>'
strDesc+='下線日期區間:'+StarDate+'-'+EndDate+'<BR>'
strDesc+='F/G入庫區間:'+StarDateM+'-'+EndDate+'<BR>'
strDesc+='<BR>Model Group Summary<BR></span>' 


# In[82]:


sMail=MyMail.MailTools()
Subject='PKG FG 持續入庫未出貨規格'
#to_Addr='chin.yang@lextar.com'
#cc_Adrr='chin.yang@lextar.com'
cc_Adrr='Lily.Lih@lextar.com,rice.lin@lextar.com,chin.yang@lextar.com,sophia.pan@lextar.com'
to_Addr='OMAA0@lextar.com,OMBA0@lextar.com,OMBF0@lextar.com,OMB03@lextar.com,LTAC1@lextar.com,SC0B0@lextar.com,'
to_Addr+='Cindy.Wang@lextar.com,Ivan.Chiu@lextar.com,Kevin.Wang@lextar.com,Frank.Ho@lextar.com,Berris.Huang@lextar.com,Light.Chen@lextar.com,Brian.lin@lextar.com,'
to_Addr+='Jeany.Liu@lextar.com,Joice.Huang@lextar.com,YY.Liao@lextar.com,Vic.Tsai@lextar.com,William.Lai@lextar.com,Jackson.Hsu@lextar.com,Ling.Chen@lextar.com'
Msg=strDesc+MsgBLMg.render()+'<BR>'+MsgLTMg.render()+'<BR>Top 10 BL Part'+'<BR>'+MsgBLPart.render()+'<BR>Top 10 LT Part'+'<BR>'+MsgLTPart.render()
sMail.SendAttachFile(Subject,Msg,FileName,to_Addr,cc_Adrr,True)


# In[83]:


# delete OldFile
DelDate=datetime.now()+relativedelta(days=-7)
DelDate=DelDate.strftime('%Y/%m/%d')
myfile='BinCode下線率_Summary'+DelDate.replace('/','')+'.xlsx'
if os.path.isfile(myfile): os.remove(myfile)    

