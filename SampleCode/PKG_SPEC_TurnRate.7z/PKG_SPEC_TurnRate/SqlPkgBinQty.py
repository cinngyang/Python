import os

class SqlStr():
                    
    def GetBU(self):
        sSQL="SELECT DISTINCT D.MODEL,D.BG "
        sSQL+=" FROM FABODS.PKG_LIABILITYDETAIL D "
        sSQL+=" WHERE D.VERSION=(SELECT MAX(VERSION) FROM FABODS.PKG_LIABILITYDETAIL) "
        sSQL+=" ORDER BY D.MODEL "
        return sSQL
    
    # 取得CIE 外BINCODE
    def GetPMCode(self,MODEL_NAME='PS06W12.2',PART_NO='95.S3806.W0A0B8N'):
        sSQL=" SELECT DISTINCT  "
        sSQL+=" BIN_TYPE, "
        sSQL+="        B.SPEC_TYPE, "
        sSQL+="        B.SPEC_CODE "
        sSQL+="   FROM R_SPEC_SET_DATA R, R_SPECVALUE_SET_DATA V, R_ENG_BASE_DATA B "
        sSQL+="  WHERE R.PART_NO = '95.S3806.W0A0C8N' "
        sSQL+="    AND MODEL_NAME = 'PS06W12.3' "
        sSQL+="    AND ACTIVE = 'Y' "
        sSQL+="    AND V.SPEC_SN = R.SN "
        sSQL+="    AND V.SPEC_CODE = B.SEQ_NO "
        sSQL+="  ORDER BY SPEC_CODE,SPEC_TYPE "
        return sSQL
    
    def GetPMCIECode(self,MODEL_NAME='PS06W12.2',PART_NO='95.S3806.W0A0B8N'):
        sSQL=" SELECT DISTINCT R.SN,'CIE' AS SPEC_TYPE,B.POS_ID AS SPEC_CODE,V.BIN_TYPE"
        sSQL+=" COLLATE CHINESE_PRC_CI_AS BIN_TYPE "
        sSQL+=" FROM R_SPEC_SET_DATA R, "
        sSQL+=" R_CIE_SET_DATA V, "
        sSQL+=" R_CIE_BASE_DATA B "
        sSQL+=" WHERE R.SN = V.CIE_SN "
        sSQL+=" AND V.BASE_ID = B.BASE_ID "
        sSQL+=" AND R.ACTIVE = 'Y' "
        sSQL+=" AND V.POS_X = B.POS_X "
        sSQL+=" AND V.POS_Y = B.POS_Y "
        sSQL+=" AND R.PART_NO='"+PART_NO+"' AND ACTIVE='Y' AND MODEL_NAME='"+MODEL_NAME+"'"
        return sSQL
               
    #Planning 料號取編碼方式
    def GetSPEC_NamingRule(self,PART_NO='95.T4014.W0B0B7Z'):
        sSQL=" SELECT DISTINCT PMS.MODEL_NAME,PMS.PART_NO,N.NAMING_RULE_NUMBER,NAMING_RULE, "
        sSQL+=" SPEC_TYPE,CODE_INDEX,CODE_LENGTH,CIE_POS_COUNT "
        sSQL+=" FROM Planning.DBO.R_ENG_SPEC_VER VER, "
        sSQL+=" Planning.DBO.C_BIN_NAMING N, "
        sSQL+=" Planning.DBO.R_SPEC_SET_DATA PMS "
        sSQL+="  WHERE VER.SEQ_NO = PMS.ENG_SPEC_ID "
        sSQL+=" AND ISMODIFY = 'Y' "
        sSQL+=" AND N.NAMING_RULE_NUMBER = VER.NAMING_RULE_NUMBER "
        sSQL+=" AND PMS.ACTIVE='Y' AND PMS.PART_NO like'"+PART_NO+"' "
        sSQL+=" ORDER BY SPEC_TYPE "
        return sSQL    
    
    def GetMinSubBin(self,MODEL_NAME='PS06W12.2',PART_NO='95.S3806.W0A0B8N',CIE='AGH0X',Othres="'QJ', 'd'"):
        sSQL="SELECT DISTINCT 'CIE' AS SPEC_TYPE, "
        sSQL+="                B.POS_ID AS SPEC_CODE, "
        sSQL+="                V.BIN_TYPE COLLATE CHINESE_PRC_CI_AS BIN_TYPE "
        sSQL+="  FROM R_SPEC_SET_DATA R, R_CIE_SET_DATA V, R_CIE_BASE_DATA B "
        sSQL+=" WHERE R.SN = V.CIE_SN "
        sSQL+="   AND V.BASE_ID = B.BASE_ID "
        sSQL+="   AND R.ACTIVE = 'Y' "
        sSQL+="   AND V.POS_X = B.POS_X "
        sSQL+="   AND V.POS_Y = B.POS_Y "
        sSQL+="   AND R.PART_NO = '"+PART_NO+"' "
        sSQL+="   AND ACTIVE = 'Y' "
        sSQL+="   AND MODEL_NAME = '"+MODEL_NAME+"' "
        sSQL+="   AND B.POS_ID = '"+CIE+"' "
        sSQL+="UNION "
        sSQL+=" SELECT DISTINCT B.SPEC_TYPE, B.SPEC_CODE, BIN_TYPE "
        sSQL+="  FROM R_SPEC_SET_DATA R, R_SPECVALUE_SET_DATA V, R_ENG_BASE_DATA B "
        sSQL+=" WHERE R.PART_NO = '"+PART_NO+"' "
        sSQL+="   AND MODEL_NAME = '"+MODEL_NAME+"' "
        sSQL+="   AND ACTIVE = 'Y' "
        sSQL+="   AND V.SPEC_SN = R.SN "
        sSQL+="   AND V.SPEC_CODE = B.SEQ_NO "
        sSQL+="   AND B.SPEC_CODE IN ("+Othres+") "
        return sSQL
    
    
    # 出貨規格與數量  
    def GetShip(self,StrDay='2018/12/31',endDay='2018/12/31'):
        sSQL="select s.productno_fgdin productno, s.bincode_fgdin bincode,sum(s.qty) ship"
        sSQL+="  from fabods.pkg_inv_ship s, fabods.dim_date d"
        sSQL+=" where d.date_index = s.date_index"
        sSQL+="   and d.date_value between to_date('"+StrDay+"', 'yyyy/MM/dd') and"
        sSQL+="       to_date('"+endDay+"', 'yyyy/MM/dd') and productno_fgdin like '95%' "
        sSQL+=" group by s.site, s.productno_fgdin, s.bincode_fgdin"
        return sSQL
    
    ### 入庫 取 F/G , 過濾 F/G , PG 在線邊未入庫, 不需過慮 
    def GepInVInput(self,StrDay='2018/12/31',EndDay='2018/12/31'):
        sSQL="select i.productno, i.bincode, sum(i.qty) input "
        sSQL+="  from fabods.pkg_inv_stockin i, fabods.dim_date d "
        sSQL+=" where d.date_index = i.date_index "
        sSQL+="   and d.date_value between to_date('"+StrDay+"', 'yyyy/MM/dd') and "
        sSQL+="       to_date('"+EndDay+"', 'yyyy/MM/dd') "
        sSQL+="   and i.mo_type <> 5  "
        sSQL+="   and i.inventoryno like 'F/G%' and productno like '95%' "
        sSQL+=" group by i.productno, i.bincode "
        return sSQL
    
    ### 目前庫存取 F/G
    #oh_type=1 , onhand
    def GetNOH(self):
        sSQL=" SELECT INV.PRODUCTNO, INV.BINCODE, SUM(INV.QTY) OH_QTY "
        sSQL+="   FROM WHMSRPT.TBLINVFGDINVENTORY INV "
        sSQL+="  WHERE INV.PRODUCTNO LIKE '95%' "
        sSQL+="    AND INV.SOURCE = 1 "
        sSQL+="    AND INV.INVENTORYNO LIKE 'F/G%' "
        sSQL+="  GROUP BY INV.PRODUCTNO, INV.BINCODE "
        return sSQL
    
    # PKG 庫存 by 工單
    def GetNOHbyWO():
        sSQL+=" SELECT INV.PRODUCTNO, "
        sSQL+="        TRUNC(SYSDATE - INV.INPUTDATE) INV_AGE, "
        sSQL+="        SUBSTR(INV.MONO, 1, 10) MONO, "
        sSQL+="        INV.BINCODE, "
        sSQL+="        SUM(INV.QTY) OH_QTY "
        sSQL+="   FROM WHMSRPT.TBLINVFGDINVENTORY INV "
        sSQL+="  WHERE INV.PRODUCTNO LIKE '95%' "
        sSQL+="    AND INV.SOURCE = 1 "
        sSQL+="    AND INV.INVENTORYNO LIKE 'F/G%' "
        sSQL+="  GROUP BY INV.PRODUCTNO, "
        sSQL+="           INV.BINCODE, "
        sSQL+="           TRUNC(SYSDATE - INV.INPUTDATE), "
        sSQL+="           SUBSTR(INV.MONO, 1, 10) "
        return sSQL    
    
    
    def GetNOHAGE(self):
        sSQL=" SELECT INV.PRODUCTNO, TRUNC(SYSDATE-INV.INPUTDATE) INV_AGE, INV.BINCODE, SUM(INV.QTY) OH_QTY "
        sSQL+="   FROM WHMSRPT.TBLINVFGDINVENTORY INV "
        sSQL+="  WHERE INV.PRODUCTNO LIKE '95%' "
        sSQL+="    AND INV.SOURCE = 1 "
        sSQL+="    AND INV.INVENTORYNO LIKE 'F/G%' "
        sSQL+="  GROUP BY INV.PRODUCTNO, INV.BINCODE, TRUNC(SYSDATE-INV.INPUTDATE) "
        return sSQL

    
    ### 工單領用 
    def GetIssueWO(self,StrDay='2018/12/31',EndDay='2018/12/31'):
        sSQL=" SELECT L.ORG, L.INVENTORYNO, L.PRODUCTNO, L.BINCODE, L.FRAME_ID, SUM(L.QTY) WO_QTY "
        sSQL+="   FROM WHMSRPT.TBLINVFGDINVENTORYLOG L "
        sSQL+="  WHERE L.STATE = 4 "
        sSQL+="    AND L.SOURCE = 1 "
        sSQL+="    AND L.REVISEDATE BETWEEN TO_DATE('"+StrDay+"', 'YYYY/MM/DD') AND  TO_DATE('"+EndDay+"', 'YYYY/MM/DD') "     
        sSQL+="    AND PRODUCTNO like '95%' AND (L.LOTNO, L.REVISEDATE) = "
        sSQL+="        (SELECT K.LOTNO, MAX(REVISEDATE) "
        sSQL+="           FROM WHMSRPT.TBLINVFGDINVENTORYLOG K "
        sSQL+="          WHERE K.LOTNO = L.LOTNO "
        sSQL+="            AND K.REVISEDATE BETWEEN TO_DATE('"+StrDay+"', 'YYYY/MM/DD') AND  TO_DATE('"+EndDay+"', 'YYYY/MM/DD') "
        sSQL+="          GROUP BY K.LOTNO) "
        sSQL+="    AND NOT EXISTS "
        sSQL+="  (SELECT 1 FROM WHMSRPT.TBLINVFGDINVENTORY M WHERE M.LOTNO = L.LOTNO) "
        sSQL+="  GROUP BY L.ORG, L.INVENTORYNO, L.PRODUCTNO, L.BINCODE, L.FRAME_ID "
        return sSQL

    
    ### 產品資訊
    def ModelProp(self):
        sql="SELECT distinct l.model_group,l.model_name,l.part_no FROM erprpt.vsinv_itf_mtl l  where l.part_no like '95%' "  
        return sql
    
    ### 成本價格
    def ItemCost(self,PERIOD_DATE='2019-02-01'):
        sSQL=" SELECT PERIOD_DATE, "
        sSQL+="        ORG, "
        sSQL+="        BG, "
        sSQL+="        SUBINV, "
        sSQL+="        LOCATOR_SEG2, "
        sSQL+="        MODEL_NAME, "
        sSQL+="        PART_NO, "
        sSQL+="        CURRENCY_FUNC, "
        sSQL+="        CURRENCY_BASE, "
        sSQL+="        SUM(QTY) QTY, "
        sSQL+="        SUM(AMT_BASE) AMT_BASE, "
        sSQL+="        ROUND(SUM(AMT_BASE) / SUM(QTY), 6) ITEM_COST_TWD "
        sSQL+="   FROM DBO.R_WH_ONHAND_AGE "
        sSQL+="  WHERE PERIOD_DATE = '"+PERIOD_DATE+"' "
        sSQL+="    AND PART_NO LIKE '95%' "
        sSQL+="    AND SUBINV LIKE 'F/G%' "      
        sSQL+="  GROUP BY PERIOD_DATE, "
        sSQL+="           ORG, "
        sSQL+="           BG, "
        sSQL+="           SUBINV, "
        sSQL+="           LOCATOR_SEG2, "
        sSQL+="           MODEL_NAME, "
        sSQL+="           PART_NO, "
        sSQL+="           CURRENCY_FUNC, "
        sSQL+="           CURRENCY_BASE "
        sSQL+="  ORDER BY PART_NO "        
        return sSQL
    
    #工單對應客戶 T01
    def GetWOCust(self):
        sSQL=" SELECT DISTINCT M.APPLICATION_TYPE, "
        sSQL+="                 M.BU_TEAM, "
        sSQL+="                 M.BU, "
        sSQL+="                 M.MONO, "
        sSQL+="                 M.PROCESS_TYPE, "
        sSQL+="                 M.PARENT_ID "
        sSQL+="   FROM FABODS.PKG_OE_MOCUSTOMER M "
        sSQL+="  WHERE M.ACTIVE = 'Y' "
        sSQL+="    AND M.MONO <> 'OTHERS' "
        return sSQL
    
    def GetTurnOffBin(self):
        sSQL="select partno,bincode "
        sSQL+=" from [Planning].[dbo].[STOCK_BINCODE_RECORD] "
        sSQL+=" where active='Y' and status='Y' "
        return sSQL
    
    #Get Mail Address
    def GetMailList(self,FUNCTIONNAME='PKG_SPEC_TURN_RATE'):
        sSQL="SELECT VALUE1 AS MAIL_LIST,VALUE2 AS MAIL_LIST_CC "
        sSQL+="  FROM FABODS.CFG_DEFINEVALUE D "
        sSQL+=" WHERE D.FUNCTIONNAME = '"+FUNCTIONNAME+"' "
        sSQL+="   AND D.DEFINECODE = 'MailList' AND D.SEQNO > 0 "
        return sSQL
    


