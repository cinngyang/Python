
class SqlStr():
    
    #FCST
    def GetFCST(self,fcstStartDay='2019/02/01',fcstEndDay='2019/02/28',Ver1,Ver2,Ver3,Ver4):
        sSQL="SELECT record_date as Week_Version, "
        sSQL+="       PKG_Model_Group, "
        sSQL+="       PKG_Model, "
        sSQL+="       bu, "
        sSQL+="       process_type, "
        sSQL+="       application_type, "
        sSQL+="       cust_group, "
        sSQL+="       SUM(PKG_Qty) AS PKG_Qty "
        sSQL+="  FROM vspace.rptom_fcst_detail da "
        sSQL+=" where da.PKG_FCST_DATE <= TO_DATE('"+fcstStartDay+"', 'YYYY/MM/DD') "
        sSQL+="   and da.PKG_FCST_DATE >= TO_DATE('"+fcstEndDay+"', 'YYYY/MM/DD') "
        sSQL+="   AND (da.record_date = '"+Ver1+"' or da.record_date = '"+Ver2+"' or "
        sSQL+="       da.record_date = '"+Ver3+"' or da.record_date = '"+Ver4+"') "
        sSQL+="   and  PKG_Model='PS06W12.3' "
        sSQL+=" GROUP BY record_date, "
        sSQL+="          PKG_Model_Group, "
        sSQL+="          PKG_Model, "
        sSQL+="          bu, "
        sSQL+="          process_type, "
        sSQL+="          application_type, "
        sSQL+="          cust_group "
        return sSQL

    # FG
    def GetINV(self,invDate='2019/02/01'):
        sSQL="SELECT oh.MODEL_GROUP, oh.MODEL_NAME, sum(oh.qty) QTY "
        sSQL+="FROM FABODS.PKG_INV_OH oh, FABODS.DIM_DATE da "
        sSQL+=" WHERE da.date_index = oh.date_index "
        sSQL+="AND da.date_value = TO_DATE('"+invDate+"', 'YYYY/MM/DD') "
        sSQL+="AND oh.oh_type = 0 "
        sSQL+="AND oh.inventoryno like 'F/G%' "
        sSQL+="AND (oh.locatorno not like '%OD%' And oh.locatorno not like '%RSK%' and "
        sSQL+="    oh.locatorno not like '%WMS%') "
        sSQL+="GROUP BY oh.MODEL_GROUP, oh.MODEL_NAME "
        return sSQL
     
    # SHIP
    def GetShip(self,startDate='2019/02/01',endDate='2019/02/28'):
        sSQL=" SELECT prd.MODEL_GROUP, prd.MODEL_NAME, sum(sh.qty) QTY "
        sSQL+=" FROM FABODS.PKG_INV_SHIP sh, "
        SQL+="   FABODS.DIM_DATE da, "
        SQL+=" (SELECT distinct model_group, model_name, part_no FROM FABODS.PKG_PRD) prd "
        SQL+=" WHERE da.date_index = sh.date_index "
        SQL+=" AND sh.productno_fgdin = prd.part_no "
        SQL+=" AND da.date_value >= TO_DATE('"+startDate+"', 'YYYY/MM/DD') "
        SQL+=" AND da.date_value <= TO_DATE('"+endDate+"', 'YYYY/MM/DD') "
        SQL+=" AND (sh.inventoryno like 'F/G%' or sh.inventoryno like 'SB%' or "
        SQL+="    sh.inventoryno like 'Material%') "
        SQL+=" GROUP BY prd.MODEL_GROUP, prd.MODEL_NAME "
        return sSQL
    
     def GetProd(self):
        sSQL=" SELECT DISTINCT PRD.MODEL_GROUP,PRD.MODEL_NAME,PRD.PART_NO, PR.APPLICATION  "
        sSQL+=" FROM   FABODS.PKG_PRD_PROPERTY PR  "
        sSQL+="       ,FABODS.PKG_PRD          PRD  "
        sSQL+=" WHERE  PRD.PART_NO = PR.PART_NO  "
        sSQL+=" AND    PRD.PART_NO LIKE '95%'  "
        sSQL+=" ORDER BY PRD.MODEL_GROUP,PRD.MODEL_NAME,PRD.PART_NO  "
        return sSQL
    
            
        